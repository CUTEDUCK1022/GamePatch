@echo on
del /Q log\*.*

